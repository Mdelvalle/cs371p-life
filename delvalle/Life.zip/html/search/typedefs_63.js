var searchData=
[
  ['const_5fpointer',['const_pointer',['../classHandle.html#a70572f1b537c269e45a4c9bb1824cbde',1,'Handle']]],
  ['const_5freference',['const_reference',['../classHandle.html#a48318242133ec8eecfadaffdd25f4e77',1,'Handle']]]
];
