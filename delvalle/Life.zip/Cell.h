// -------
// Cell.h
// -------

#ifndef Cell_h
#define Cell_h

// INCLUDES
#include "Handle.h"
#include "AbstractCell.h"
#include "ConwayCell.h"
#include "FredkinCell.h"

class Cell : public Handle<AbstractCell> {
	public:
    	AbstractCell* ac;
    	Cell();
    	Cell(AbstractCell* p);

        // makes the _alive variable equal to the bool passed in
        virtual void alive(bool);
            // returns the _alive variable
        virtual bool alive();
            // makes the _liveNeighbours variable equal to the int passed in
        virtual void liveNeighbours(int);
                // returns the _liveNeighbours variable
        virtual int liveNeighbours();
        // increments _age for fredkin
    	virtual void inc_age();
            // returns the type of the object
		virtual std::string type();
            // returns true if the FredkinCell can mutate
		virtual bool can_mutate();
    	virtual void mutate();
        // Reads in the character and stores it in the grid
    	virtual std::istream& read (std::istream&);
            // writes the character associated with the object to the .out file
    	virtual std::ostream& write (std::ostream&) const;
};

#endif // Cell_h
