var searchData=
[
  ['simulate',['simulate',['../classLife.html#a927e88b18411fd11b5a499a46b99fcf9',1,'Life']]],
  ['store_5fcells',['store_cells',['../classLife.html#a4a2ec48abf95f0de37453d0190795461',1,'Life']]],
  ['swap',['swap',['../classHandle.html#a48f95f0130205c87c1141e576eb2992f',1,'Handle']]]
];
