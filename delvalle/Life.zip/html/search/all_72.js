var searchData=
[
  ['read',['read',['../classAbstractCell.html#a67d30f084252c394138fd99e5c24cb3b',1,'AbstractCell::read()'],['../classCell.html#a68c1f2cdae7a3361aacf07d1be8d9583',1,'Cell::read()'],['../classConwayCell.html#a46e1c8ec36d9392ae91bbe01dce1611f',1,'ConwayCell::read()'],['../classFredkinCell.html#a7a78db4a4f469ea3a1cc3dd60c79c316',1,'FredkinCell::read()']]],
  ['reference',['reference',['../classHandle.html#a37f4011e5a2de2482f6b494fa65a82d0',1,'Handle']]],
  ['runlife_2ec_2b_2b',['RunLife.c++',['../RunLife_8c_09_09.html',1,'']]]
];
