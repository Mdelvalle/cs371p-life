var searchData=
[
  ['_5fage',['_age',['../classFredkinCell.html#a2486375e903e4fec0a43d1b183fc1098',1,'FredkinCell']]],
  ['_5falive',['_alive',['../classAbstractCell.html#acc1709ac6a09244b76c38dca45577111',1,'AbstractCell']]],
  ['_5fcolumns',['_columns',['../classLife.html#a178c6c9b1c9efff81daf12e959ab92bb',1,'Life']]],
  ['_5fgrid',['_grid',['../classLife.html#a05c6db4d8c0e7c26b1b16b10ae10f537',1,'Life']]],
  ['_5fliveneighbours',['_liveNeighbours',['../classAbstractCell.html#aef1bfad002672576afe92ebe1985838f',1,'AbstractCell']]],
  ['_5fp',['_p',['../classHandle.html#ad74f33e968f57f03dd7e6a2be10b8cd2',1,'Handle']]],
  ['_5frows',['_rows',['../classLife.html#a84f806f6449ad979797d9519ed8bd06d',1,'Life']]]
];
