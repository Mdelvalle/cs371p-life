var searchData=
[
  ['_7ehandle',['~Handle',['../classHandle.html#af44781eaf3bf4a8dc43c03bbffb6a99b',1,'Handle']]]
];
