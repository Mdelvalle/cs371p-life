var searchData=
[
  ['handle',['Handle',['../classHandle.html#acae37b04162b307d903b008a52b6bf95',1,'Handle::Handle(pointer p)'],['../classHandle.html#ad4a4e85ee6c84a4acb84f546d475b09c',1,'Handle::Handle(const Handle &amp;that)']]]
];
