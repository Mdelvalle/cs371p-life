var searchData=
[
  ['pointer',['pointer',['../classHandle.html#ae12984dd0ac986f1395eb5f3d6be88e5',1,'Handle']]]
];
