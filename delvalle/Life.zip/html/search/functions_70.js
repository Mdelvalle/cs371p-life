var searchData=
[
  ['print',['print',['../classLife.html#a0562f7211ec07ebb687930a3fc8d8dd0',1,'Life']]]
];
