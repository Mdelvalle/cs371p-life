var searchData=
[
  ['get',['get',['../classHandle.html#ac8d3293e5dd407a126726e6f9f6dcc5e',1,'Handle::get()'],['../classHandle.html#a43f144b815aa32fe2f2bf28627ed341b',1,'Handle::get() const ']]]
];
