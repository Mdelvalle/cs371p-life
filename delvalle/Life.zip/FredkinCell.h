// --------------
// FredkinCell.h
// --------------

#ifndef FredKinCell_h
#define FredKinCell_h

// INCLUDES
#include "AbstractCell.h"

class FredkinCell : public AbstractCell {
public:
	int _age;
	FredkinCell();
	void inc_age();
	// makes the _alive variable equal to the bool passed in
	virtual void alive(bool);
	// returns the _alive variable
	virtual bool alive();
	// makes the _liveNeighbours variable equal to the int passed in
    virtual void liveNeighbours(int);
    // returns the _liveNeighbours variable
    virtual int liveNeighbours();
    // returns the type of the object
	virtual std::string type();
	// returns true if the FredkinCell can mutate
	virtual bool can_mutate();
	// mutates the cell
	virtual void mutate();
	// clones
	virtual FredkinCell* clone() const;
	// Reads in the character and stores it in the grid
	virtual std::istream& read (std::istream&);
	// writes the character associated with the object to the .out file
	virtual std::ostream& write (std::ostream&) const;
};

#endif // FredkinCell_h
