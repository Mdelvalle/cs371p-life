var searchData=
[
  ['in_5finterior',['in_interior',['../classLife.html#a310579f30d8eaa157b77afa519b8ebe2',1,'Life']]],
  ['inc_5fage',['inc_age',['../classAbstractCell.html#a00a8b111bd2797b9c700b441345c1bf9',1,'AbstractCell::inc_age()'],['../classCell.html#a6bebd1b1cb987f7236f9e4240455c5e4',1,'Cell::inc_age()'],['../classConwayCell.html#a055ec06171e044fff128d2476228a665',1,'ConwayCell::inc_age()'],['../classFredkinCell.html#add158df5570233377d65e6a04ba6334e',1,'FredkinCell::inc_age()']]]
];
