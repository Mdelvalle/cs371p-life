// ---------------
// AbstractCell.h
// ---------------

#ifndef AbstractCell_h
#define AbstractCell_h

// INCLUDES
#include <iostream> // istream, ostream
#include <utility> // !=

class AbstractCell {

public:
	bool _alive;
  int _liveNeighbours;

	AbstractCell();
    // makes the _alive variable equal to the bool passed in
  virtual void alive(bool) = 0;
    // returns the _alive variable
  virtual bool alive() = 0;
    // makes the _liveNeighbours variable equal to the int passed in
  virtual void liveNeighbours(int) = 0;
    // returns the _liveNeighbours variable
  virtual int liveNeighbours() = 0;
  // increments _age for fredkin
  virtual void inc_age() = 0;
    // returns true if the FredkinCell can mutate
  virtual bool can_mutate() = 0;
    // mutates the cell
  virtual void mutate() = 0;
        // returns the type of the object
  virtual std::string type() = 0;
  // clones
  virtual AbstractCell* clone() const = 0;
    // Reads in the character and stores it in the grid
  virtual std::istream& read (std::istream& in) = 0;
    // writes the character associated with the object to the .out file
  virtual std::ostream& write (std::ostream& out) const = 0;
};

#endif // AbstractCell_h
