var searchData=
[
  ['live_5fcells',['live_cells',['../classLife.html#a014abb70eebf44285b5b2cbee7444f54',1,'Life']]],
  ['live_5fneighbours',['live_neighbours',['../classLife.html#aa8d424de632468c57cc4cf351e63f0a2',1,'Life']]],
  ['liveneighbours',['liveNeighbours',['../classAbstractCell.html#ab30c87a32819c8020fa49706cca112c0',1,'AbstractCell::liveNeighbours(int)=0'],['../classAbstractCell.html#ac06e89c7de329f70bff90071c364624c',1,'AbstractCell::liveNeighbours()=0'],['../classCell.html#a1152f370cf6880f8d396f9240dacde66',1,'Cell::liveNeighbours(int)'],['../classCell.html#a4a6066b4406e924a076a267a5604b6eb',1,'Cell::liveNeighbours()'],['../classConwayCell.html#a9c376311d45a4596033dde3c40f9dd75',1,'ConwayCell::liveNeighbours(int)'],['../classConwayCell.html#a27247b4548d5e2d93f0f8f6ad3baf1a7',1,'ConwayCell::liveNeighbours()'],['../classFredkinCell.html#a4addf18095ee5fb3e29df4e872704213',1,'FredkinCell::liveNeighbours(int)'],['../classFredkinCell.html#ac7a8116f898368ed5b8d90368af44f06',1,'FredkinCell::liveNeighbours()']]]
];
